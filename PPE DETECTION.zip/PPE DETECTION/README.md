# PPE Detection Streamlit App

This folder contains a Streamlit application that runs live PPE detection using your YOLO model and shows results in a simple dashboard.

Files:
- `streamlit_app.py` — Streamlit app that runs camera inference in a background thread and shows live frames and summary metrics.
- `requirements.txt` — Python dependencies.

How it works
- The app uses your model at `model/best .pt` (keep the exact filename as in the repo).
- The app also watches `live_data.json` in the same folder. External processes (for example a terminal script) can write detection counts there and the app will display them in the sidebar.

Example: push detection JSON from terminal (PowerShell)

Create a small JSON file manually or by a one-liner. Example writes a dictionary where keys are class names and values are counts:

```
echo '{"No-Helmet": 1, "Helmet": 2}' | Out-File -Encoding utf8 live_data.json
```

This will be picked up by the Streamlit app and merged with live camera counts.

Run the app

1. Create a virtual environment and install requirements:

```
python -m venv .venv; .\.venv\Scripts\Activate; pip install -r requirements.txt
```

2. Run Streamlit:

```
streamlit run streamlit_app.py
```

Notes
- If your model filename or location is different update `MODEL_PATH` in `streamlit_app.py`.
- The app tries to find the first working camera index (0..3).
