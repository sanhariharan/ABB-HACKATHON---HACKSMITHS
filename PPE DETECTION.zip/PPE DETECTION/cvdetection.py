import cv2
import torch
from ultralytics import YOLO

MODEL_PATH = './model/best .pt'
model = YOLO(MODEL_PATH)

# Try different camera indices to find the real webcam
for cam_index in range(0, 4):
    cap = cv2.VideoCapture(cam_index)
    if cap.isOpened():
        print(f"Testing camera index {cam_index}...")
        ret, frame = cap.read()
        if ret:
            cv2.imshow(f'Camera {cam_index} - Press any key', frame)
            cv2.waitKey(2000)
            cv2.destroyAllWindows()
            cap.release()
            use_index = cam_index
            break
        cap.release()
else:
    print("No working camera found.")
    exit()

cap = cv2.VideoCapture(use_index)
CLASS_NAMES = ['Gloves', 'Helmet', 'No-Gloves', 'No-Helmet', 'No-Shoes', 'No-Vest', 'Shoes', 'Vest']

# Set camera resolution to maximum available
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

# Create a named window that can be resized
cv2.namedWindow('PPE Detection - YOLOv8', cv2.WINDOW_NORMAL)
# Set initial window size to full screen
cv2.setWindowProperty('PPE Detection - YOLOv8', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Error: Failed to capture frame.")
        break
    
    # Get the actual frame dimensions
    height, width = frame.shape[:2]
    print(f"Camera resolution: {width}x{height}")
    
    results = model(frame, imgsz=640, conf=0.25)
    boxes = results[0].boxes
    for box in boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = float(box.conf[0])
        cls = int(box.cls[0])
        label = f"{CLASS_NAMES[cls]} {conf:.2f}"
        color = (0, 255, 0) if conf > 0.5 else (0, 0, 255)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    
    cv2.imshow('PPE Detection - YOLOv8', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()