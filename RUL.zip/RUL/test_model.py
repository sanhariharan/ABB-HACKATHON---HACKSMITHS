"""
Simple test harness to load the trained model and preprocessor from `optimized_rul` and evaluate on the test split.
"""
import pickle
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model

# Ensure classes are importable for pickle
from main import OptimizedRULPreprocessor

base_dir = Path('optimized_rul')
model_path = base_dir / 'models' / 'optimized_rul_final.h5'
preprocessor_path = base_dir / 'models' / 'optimized_preprocessor.pkl'
metrics_path = base_dir / 'results' / 'optimized_metrics.json'

if not preprocessor_path.exists() or not model_path.exists():
    print('Preprocessor or model not found. Please run main.py to train and save artifacts first.')
    raise SystemExit(1)

# Load artifacts
with open(preprocessor_path, 'rb') as f:
    preprocessor = pickle.load(f)

model = load_model(str(model_path))

# Load data
data_path = base_dir / 'data' / 'optimized_motor_data.csv'
if not data_path.exists():
    print('Dataset not found at', data_path)
    raise SystemExit(1)

data = pd.read_csv(data_path)
data['timestamp'] = pd.to_datetime(data['timestamp'])

# Recreate windows and splits
X, y, metadata = preprocessor.create_training_windows(data)
X_splits, y_splits, y_original = preprocessor.split_and_scale(X, y, metadata)
_, _, X_test = X_splits
_, _, y_test = y_splits
_, _, y_test_orig = y_original

# Predict
y_pred_scaled = model.predict(X_test, batch_size=256)
# Inverse transform the RUL scaler
rul_scaler = preprocessor.rul_scaler
if rul_scaler is None:
    print('RUL scaler missing in preprocessor')
    raise SystemExit(1)

# reverse scaling
y_pred_log = rul_scaler.inverse_transform(y_pred_scaled).flatten()
# reverse log1p
y_pred = np.expm1(y_pred_log)

# y_test is scaled; get original y_test from y_test_orig
y_true = y_test_orig

# Compute simple metrics
mae = np.mean(np.abs(y_true - y_pred))
rmse = np.sqrt(np.mean((y_true - y_pred)**2))

print('Test results:')
print(f'  Samples: {len(y_true)}')
print(f'  MAE: {mae:.3f} hours')
print(f'  RMSE: {rmse:.3f} hours')

# Save predictions
out_df = pd.DataFrame({'true_rul': y_true, 'pred_rul': y_pred})
out_path = base_dir / 'results' / 'test_predictions.csv'
out_df.to_csv(out_path, index=False)
print('Saved predictions to', out_path)

# Compute comprehensive metrics and save them (overwrites broken JSON if necessary)
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

mae = mean_absolute_error(y_true, y_pred)
rmse = mean_squared_error(y_true, y_pred, squared=False)
r2 = r2_score(y_true, y_pred)
bias = (y_pred - y_true).mean()

def within_pct(y_true, y_pred, tol):
    return 100.0 * np.mean(np.abs(y_true - y_pred) <= tol)

metrics = {
    'Accuracy_%': 100.0 * np.mean(np.isclose(y_true, np.round(y_pred), atol=0.5)),
    'MAE': float(mae),
    'RMSE': float(rmse),
    'R²': float(r2),
    'Within_3h_%': float(within_pct(y_true, y_pred, 3)),
    'Within_6h_%': float(within_pct(y_true, y_pred, 6)),
    'Within_12h_%': float(within_pct(y_true, y_pred, 12)),
    'Bias': float(bias)
}

with open(metrics_path, 'w') as f:
    json.dump(metrics, f, indent=2)

print('\nComputed metrics:')
for k, v in metrics.items():
    print(f'  {k}: {v}')
