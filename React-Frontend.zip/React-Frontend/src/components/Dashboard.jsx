import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Header from './Header'
import SystemFlow from './SystemFlow'
import NodeModal from './NodeModal'
import StatusPanel from './StatusPanel'

const Dashboard = () => {
  const [selectedNode, setSelectedNode] = useState(null)
  const [systemStatus, setSystemStatus] = useState({
    plc: 'active',
    esp32: 'active',
    influxdb: 'active',
    arTwin: 'active',
    rulPrediction: 'warning',
    anomalyDetection: 'alert',
    ppeDetection: 'active'
  })

  const [realTimeData, setRealTimeData] = useState({
    motor: {
      frequency: 50.2,
      voltage: 380.5,
      current: 12.8,
      rpm: 1450,
      temperature: 68.5
    },
    plc: {
      registers: 156,
      lastUpdate: new Date().toISOString()
    },
    anomalies: [
      { type: 'vibration', severity: 'medium', timestamp: new Date() },
      { type: 'temperature', severity: 'high', timestamp: new Date() }
    ],
    rul: {
      remainingDays: 45,
      healthScore: 78,
      trend: 'declining'
    }
  })

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        ...prev,
        motor: {
          ...prev.motor,
          frequency: 50 + Math.random() * 2,
          voltage: 380 + Math.random() * 10,
          current: 12 + Math.random() * 3,
          rpm: 1450 + Math.random() * 100,
          temperature: 65 + Math.random() * 10
        },
        plc: {
          ...prev.plc,
          lastUpdate: new Date().toISOString()
        }
      }))
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const handleNodeClick = (nodeId) => {
    setSelectedNode(nodeId)
  }

  const closeModal = () => {
    setSelectedNode(null)
  }

  return (
    <div className="min-h-screen bg-cyber-dark text-white">
      {/* Cyber Grid Background */}
      <div className="fixed inset-0 cyber-grid opacity-20 pointer-events-none" />
      
      {/* Header */}
      <Header systemStatus={systemStatus} />
      
      {/* Main Dashboard Content */}
      <main className="container mx-auto px-4 py-8 relative z-10">
        {/* Status Panel */}
        <StatusPanel realTimeData={realTimeData} />
        
        {/* System Flow Diagram */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-8"
        >
          <SystemFlow 
            onNodeClick={handleNodeClick}
            realTimeData={realTimeData}
            systemStatus={systemStatus}
          />
        </motion.div>
      </main>

      {/* Node Modal */}
      {selectedNode && (
        <NodeModal
          nodeId={selectedNode}
          onClose={closeModal}
          realTimeData={realTimeData}
        />
      )}
    </div>
  )
}

export default Dashboard
