import React from 'react'
import { motion } from 'framer-motion'

const FlowConnection = ({ from, to, active, delay = 0 }) => {
  // Calculate connection path
  const dx = to.x - from.x
  const dy = to.y - from.y
  const length = Math.sqrt(dx * dx + dy * dy)
  const angle = Math.atan2(dy, dx) * 180 / Math.PI

  // Adjust positions to account for node size
  const nodeRadius = 40
  const startX = from.x + (dx / length) * nodeRadius
  const startY = from.y + (dy / length) * nodeRadius
  const endX = to.x - (dx / length) * nodeRadius
  const endY = to.y - (dy / length) * nodeRadius

  const adjustedLength = Math.sqrt((endX - startX) ** 2 + (endY - startY) ** 2)

  return (
    <div
      className="absolute pointer-events-none"
      style={{
        left: startX,
        top: startY,
        width: adjustedLength,
        height: 2,
        transform: `rotate(${angle}deg)`,
        transformOrigin: 'left center'
      }}
    >
      {/* Base connection line */}
      <motion.div
        className="w-full h-full bg-cyber-blue/30"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1, delay }}
      />

      {/* Animated data flow */}
      {active && (
        <motion.div
          className="absolute top-0 h-full w-8 bg-gradient-to-r from-transparent via-cyber-blue to-transparent"
          initial={{ x: -32 }}
          animate={{ x: adjustedLength }}
          transition={{
            duration: 2,
            repeat: Infinity,
            delay: delay,
            ease: "easeInOut"
          }}
        />
      )}

      {/* Data particles */}
      {active && (
        <>
          <motion.div
            className="absolute top-0 left-0 w-2 h-2 bg-cyber-blue rounded-full"
            initial={{ x: 0, opacity: 0 }}
            animate={{ 
              x: adjustedLength - 8, 
              opacity: [0, 1, 1, 0] 
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: delay + 0.2,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute top-0 left-0 w-1 h-1 bg-cyber-purple rounded-full"
            initial={{ x: 0, opacity: 0 }}
            animate={{ 
              x: adjustedLength - 4, 
              opacity: [0, 1, 1, 0] 
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: delay + 0.5,
              ease: "easeInOut"
            }}
          />
        </>
      )}

      {/* Arrow indicator */}
      <motion.div
        className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-1"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: delay + 1 }}
      >
        <svg width="8" height="8" viewBox="0 0 8 8">
          <path
            d="M0,4 L8,0 L8,8 Z"
            fill="#00f5ff"
            className="drop-shadow-lg"
          />
        </svg>
      </motion.div>
    </div>
  )
}

export default FlowConnection
