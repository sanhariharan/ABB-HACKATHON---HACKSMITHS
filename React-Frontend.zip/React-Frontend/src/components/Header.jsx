import React from 'react'
import { motion } from 'framer-motion'
import { Activity, Wifi, Database, Shield, AlertTriangle } from 'lucide-react'

const Header = ({ systemStatus }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'text-cyber-green'
      case 'warning': return 'text-yellow-400'
      case 'alert': return 'text-red-400'
      default: return 'text-cyber-blue'
    }
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active': return <Activity className="w-4 h-4" />
      case 'warning': return <AlertTriangle className="w-4 h-4" />
      case 'alert': return <AlertTriangle className="w-4 h-4" />
      default: return <Activity className="w-4 h-4" />
    }
  }

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="bg-cyber-gray/30 backdrop-blur-sm border-b border-cyber-blue/30 px-6 py-4"
    >
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo and Title */}
        <div className="flex items-center space-x-4">
          <motion.div
            className="text-3xl font-bold text-cyber-blue"
            animate={{ textShadow: ['0 0 10px #00f5ff', '0 0 20px #00f5ff', '0 0 10px #00f5ff'] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            INDUSTRY 4.0
          </motion.div>
          <div className="h-8 w-px bg-cyber-blue/50" />
          <div className="text-sm text-cyber-purple">
            Dark Factory Automation System
          </div>
        </div>

        {/* System Status Indicators */}
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className={`${getStatusColor(systemStatus.plc)} flex items-center space-x-1`}>
                {getStatusIcon(systemStatus.plc)}
                <span className="text-xs">PLC</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className={`${getStatusColor(systemStatus.esp32)} flex items-center space-x-1`}>
                <Wifi className="w-4 h-4" />
                <span className="text-xs">ESP32</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className={`${getStatusColor(systemStatus.influxdb)} flex items-center space-x-1`}>
                <Database className="w-4 h-4" />
                <span className="text-xs">InfluxDB</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className={`${getStatusColor(systemStatus.ppeDetection)} flex items-center space-x-1`}>
                <Shield className="w-4 h-4" />
                <span className="text-xs">PPE</span>
              </div>
            </div>
          </div>

          {/* Real-time Clock */}
          <motion.div
            className="text-cyber-blue font-mono text-sm"
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            {new Date().toLocaleTimeString()}
          </motion.div>
        </div>
      </div>
    </motion.header>
  )
}

export default Header
