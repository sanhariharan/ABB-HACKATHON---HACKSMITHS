import React, { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Camera, Play, Stop } from 'lucide-react'
import Webcam from 'react-webcam'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const NodeModal = ({ nodeId, onClose, realTimeData }) => {
  const [isWebcamActive, setIsWebcamActive] = useState(false)
  const [ppeDetections, setPpeDetections] = useState([])
  const webcamRef = useRef(null)

  // Mock historical data for charts
  const [historicalData] = useState(() => {
    const data = []
    for (let i = 0; i < 24; i++) {
      data.push({
        time: `${i}:00`,
        temperature: 65 + Math.random() * 10,
        rpm: 1450 + Math.random() * 100,
        current: 12 + Math.random() * 3
      })
    }
    return data
  })

  const startWebcam = () => {
    setIsWebcamActive(true)
    // Simulate PPE detection
    const detectInterval = setInterval(() => {
      const detections = [
        { item: 'helmet', detected: Math.random() > 0.3, confidence: 0.85 },
        { item: 'vest', detected: Math.random() > 0.4, confidence: 0.92 },
        { item: 'gloves', detected: Math.random() > 0.5, confidence: 0.78 },
        { item: 'shoes', detected: Math.random() > 0.2, confidence: 0.89 }
      ]
      setPpeDetections(detections)
    }, 2000)

    return () => clearInterval(detectInterval)
  }

  const stopWebcam = () => {
    setIsWebcamActive(false)
    setPpeDetections([])
  }

  const getModalContent = () => {
    switch (nodeId) {
      case 'sensors':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-cyber-blue">Motor Sensors</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="cyber-panel">
                <h3 className="text-lg text-cyber-green mb-4">Real-time Data</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Frequency:</span>
                    <span className="text-cyber-blue">{realTimeData.motor.frequency.toFixed(2)} Hz</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Voltage:</span>
                    <span className="text-cyber-green">{realTimeData.motor.voltage.toFixed(2)} V</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Current:</span>
                    <span className="text-cyber-purple">{realTimeData.motor.current.toFixed(2)} A</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RPM:</span>
                    <span className="text-yellow-400">{Math.round(realTimeData.motor.rpm)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Temperature:</span>
                    <span className={realTimeData.motor.temperature > 70 ? 'text-red-400' : 'text-cyber-blue'}>
                      {realTimeData.motor.temperature.toFixed(1)}°C
                    </span>
                  </div>
                </div>
              </div>
              <div className="cyber-panel">
                <h3 className="text-lg text-cyber-green mb-4">24h Trend</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={historicalData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#00f5ff20" />
                    <XAxis dataKey="time" stroke="#00f5ff" />
                    <YAxis stroke="#00f5ff" />
                    <Tooltip 
                      contentStyle={{ 
                        background: '#1a1a1a', 
                        border: '1px solid #00f5ff',
                        borderRadius: '8px'
                      }} 
                    />
                    <Line type="monotone" dataKey="temperature" stroke="#00f5ff" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )

      case 'plc':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-cyber-blue">Mitsubishi PLC FX5UMT/ESS</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="cyber-panel">
                <h3 className="text-lg text-cyber-green mb-4">System Status</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Status:</span>
                    <span className="text-cyber-green">ONLINE</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Active Registers:</span>
                    <span className="text-cyber-blue">{realTimeData.plc.registers}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Last Update:</span>
                    <span className="text-gray-400 text-sm">
                      {new Date(realTimeData.plc.lastUpdate).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Connection:</span>
                    <span className="text-cyber-green">Modbus TCP</span>
                  </div>
                </div>
              </div>
              <div className="cyber-panel">
                <h3 className="text-lg text-cyber-green mb-4">Performance</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>CPU Load:</span>
                    <span className="text-cyber-blue">23%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Memory Usage:</span>
                    <span className="text-cyber-purple">45%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Cycle Time:</span>
                    <span className="text-yellow-400">2.5ms</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>I/O Status:</span>
                    <span className="text-cyber-green">ALL OK</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )

      case 'anomaly':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-cyber-blue">Anomaly Detection</h2>
            <div className="cyber-panel">
              <h3 className="text-lg text-red-400 mb-4">Active Anomalies</h3>
              <div className="space-y-3">
                {realTimeData.anomalies.map((anomaly, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center justify-between p-3 bg-red-400/10 border border-red-400/30 rounded-lg"
                    animate={{ opacity: [0.7, 1, 0.7] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <div>
                      <div className="text-red-400 font-semibold capitalize">{anomaly.type}</div>
                      <div className="text-xs text-gray-400">
                        {anomaly.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                    <div className={`px-2 py-1 rounded text-xs ${
                      anomaly.severity === 'high' ? 'bg-red-400 text-white' :
                      anomaly.severity === 'medium' ? 'bg-yellow-400 text-black' :
                      'bg-green-400 text-black'
                    }`}>
                      {anomaly.severity.toUpperCase()}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )

      case 'ppe':
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-cyber-blue">PPE Detection System</h2>
            <div className="cyber-panel">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg text-cyber-green">YOLOv8 Real-time Detection</h3>
                <div className="flex items-center space-x-2">
                  {!isWebcamActive ? (
                    <button
                      onClick={startWebcam}
                      className="cyber-button flex items-center space-x-2"
                    >
                      <Camera className="w-4 h-4" />
                      <span>Start Camera</span>
                    </button>
                  ) : (
                    <button
                      onClick={stopWebcam}
                      className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2"
                    >
                      <Stop className="w-4 h-4" />
                      <span>Stop Camera</span>
                    </button>
                  )}
                </div>
              </div>
              
              {isWebcamActive && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="relative">
                    <Webcam
                      ref={webcamRef}
                      className="w-full rounded-lg border border-cyber-blue"
                      screenshotFormat="image/jpeg"
                    />
                    {/* Detection Overlay */}
                    <div className="absolute top-2 left-2 space-y-1">
                      {ppeDetections.map((detection, index) => (
                        <div
                          key={detection.item}
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            detection.detected 
                              ? 'bg-green-500 text-white' 
                              : 'bg-red-500 text-white'
                          }`}
                        >
                          {detection.item}: {detection.detected ? 'DETECTED' : 'MISSING'}
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-lg text-cyber-green">Detection Results</h4>
                    {ppeDetections.map((detection, index) => (
                      <div key={detection.item} className="flex items-center justify-between">
                        <span className="capitalize">{detection.item}:</span>
                        <div className="flex items-center space-x-2">
                          <span className={detection.detected ? 'text-green-400' : 'text-red-400'}>
                            {detection.detected ? 'DETECTED' : 'MISSING'}
                          </span>
                          <span className="text-gray-400 text-xs">
                            ({(detection.confidence * 100).toFixed(0)}%)
                          </span>
                        </div>
                      </div>
                    ))}
                    
                    {ppeDetections.some(d => !d.detected) && (
                      <motion.div
                        className="p-3 bg-red-400/20 border border-red-400/50 rounded-lg"
                        animate={{ opacity: [0.7, 1, 0.7] }}
                        transition={{ duration: 1, repeat: Infinity }}
                      >
                        <div className="text-red-400 font-semibold">SAFETY VIOLATION DETECTED</div>
                        <div className="text-xs text-gray-400 mt-1">
                          Triggering PLC safety stop sequence...
                        </div>
                      </motion.div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )

      default:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-cyber-blue">Node Information</h2>
            <div className="cyber-panel">
              <p className="text-gray-300">Detailed information for {nodeId} node.</p>
            </div>
          </div>
        )
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-cyber-gray/90 backdrop-blur-sm border border-cyber-blue/50 rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-cyber-green rounded-full animate-pulse" />
              <span className="text-cyber-blue font-mono">LIVE DATA</span>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {getModalContent()}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default NodeModal
