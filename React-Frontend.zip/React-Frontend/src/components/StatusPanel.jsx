import React from 'react'
import { motion } from 'framer-motion'
import { Gauge, Thermometer, Zap, RotateCcw, AlertTriangle, TrendingDown } from 'lucide-react'

const StatusPanel = ({ realTimeData }) => {
  const metrics = [
    {
      icon: <Gauge className="w-5 h-5" />,
      label: 'Frequency',
      value: `${realTimeData.motor.frequency.toFixed(1)} Hz`,
      color: 'text-cyber-blue'
    },
    {
      icon: <Zap className="w-5 h-5" />,
      label: 'Voltage',
      value: `${realTimeData.motor.voltage.toFixed(1)} V`,
      color: 'text-cyber-green'
    },
    {
      icon: <Zap className="w-5 h-5" />,
      label: 'Current',
      value: `${realTimeData.motor.current.toFixed(1)} A`,
      color: 'text-cyber-purple'
    },
    {
      icon: <RotateCcw className="w-5 h-5" />,
      label: 'RPM',
      value: `${Math.round(realTimeData.motor.rpm)}`,
      color: 'text-yellow-400'
    },
    {
      icon: <Thermometer className="w-5 h-5" />,
      label: 'Temperature',
      value: `${realTimeData.motor.temperature.toFixed(1)}°C`,
      color: realTimeData.motor.temperature > 70 ? 'text-red-400' : 'text-cyber-blue'
    }
  ]

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8"
    >
      {/* Motor Metrics */}
      {metrics.map((metric, index) => (
        <motion.div
          key={metric.label}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          className="cyber-panel"
        >
          <div className="flex items-center justify-between mb-2">
            <div className={`${metric.color}`}>
              {metric.icon}
            </div>
            <div className="text-xs text-gray-400 font-mono">
              LIVE
            </div>
          </div>
          <div className="text-lg font-bold text-white mb-1">
            {metric.value}
          </div>
          <div className="text-xs text-gray-400">
            {metric.label}
          </div>
        </motion.div>
      ))}

      {/* System Health Overview */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: 0.6 }}
        className="md:col-span-3 lg:col-span-2 cyber-panel"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-cyber-blue">System Health</h3>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-cyber-green rounded-full animate-pulse" />
            <span className="text-xs text-gray-400">OPERATIONAL</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* RUL Status */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <TrendingDown className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-gray-300">Remaining Useful Life</span>
            </div>
            <div className="text-2xl font-bold text-yellow-400">
              {realTimeData.rul.remainingDays} days
            </div>
            <div className="text-xs text-gray-400">
              Health Score: {realTimeData.rul.healthScore}%
            </div>
          </div>

          {/* Anomaly Status */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <span className="text-sm text-gray-300">Active Anomalies</span>
            </div>
            <div className="text-2xl font-bold text-red-400">
              {realTimeData.anomalies.length}
            </div>
            <div className="text-xs text-gray-400">
              {realTimeData.anomalies.length > 0 ? 'Attention Required' : 'All Clear'}
            </div>
          </div>
        </div>
      </motion.div>

      {/* PLC Status */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: 0.7 }}
        className="cyber-panel"
      >
        <div className="flex items-center justify-between mb-2">
          <div className="text-cyber-blue">
            <Gauge className="w-5 h-5" />
          </div>
          <div className="text-xs text-gray-400 font-mono">
            PLC
          </div>
        </div>
        <div className="text-lg font-bold text-white mb-1">
          {realTimeData.plc.registers}
        </div>
        <div className="text-xs text-gray-400">
          Active Registers
        </div>
      </motion.div>
    </motion.div>
  )
}

export default StatusPanel
