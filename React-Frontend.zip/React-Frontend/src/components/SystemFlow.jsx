import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import SystemNode from './SystemNode'
import FlowConnection from './FlowConnection'

const SystemFlow = ({ onNodeClick, realTimeData, systemStatus }) => {
  const [dataFlow, setDataFlow] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setDataFlow(prev => !prev)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const nodes = [
    {
      id: 'sensors',
      name: 'Motor Sensors',
      type: 'sensor',
      position: { x: 50, y: 200 },
      status: 'active',
      data: realTimeData.motor,
      description: 'Frequency, Voltage, Current, RPM, Temperature'
    },
    {
      id: 'vfd',
      name: 'VFD Controller',
      type: 'vfd',
      position: { x: 250, y: 200 },
      status: 'active',
      data: { frequency: realTimeData.motor.frequency },
      description: 'Variable Frequency Drive'
    },
    {
      id: 'plc',
      name: 'Mitsubishi PLC',
      type: 'plc',
      position: { x: 450, y: 200 },
      status: systemStatus.plc,
      data: realTimeData.plc,
      description: 'FX5UMT/ESS Controller'
    },
    {
      id: 'esp32',
      name: 'ESP32 Edge',
      type: 'esp32',
      position: { x: 650, y: 200 },
      status: systemStatus.esp32,
      data: { anomalies: realTimeData.anomalies.length },
      description: 'Edge AI & Modbus TCP'
    },
    {
      id: 'mqtt',
      name: 'MQTT Gateway',
      type: 'mqtt',
      position: { x: 850, y: 200 },
      status: 'active',
      data: { protocol: 'Sparkplug B' },
      description: 'Industrial IoT Protocol'
    },
    {
      id: 'influxdb',
      name: 'InfluxDB',
      type: 'database',
      position: { x: 1050, y: 200 },
      status: systemStatus.influxdb,
      data: { records: 15420 },
      description: 'Time Series Database'
    },
    {
      id: 'artwin',
      name: 'AR Digital Twin',
      type: 'ar',
      position: { x: 950, y: 50 },
      status: systemStatus.arTwin,
      data: { sync: 'real-time' },
      description: 'Augmented Reality Model'
    },
    {
      id: 'rul',
      name: 'RUL Prediction',
      type: 'ai',
      position: { x: 950, y: 350 },
      status: systemStatus.rulPrediction,
      data: realTimeData.rul,
      description: 'Remaining Useful Life AI'
    },
    {
      id: 'anomaly',
      name: 'Anomaly Detection',
      type: 'alert',
      position: { x: 650, y: 50 },
      status: systemStatus.anomalyDetection,
      data: { alerts: realTimeData.anomalies },
      description: 'Edge AI Detection'
    },
    {
      id: 'ppe',
      name: 'PPE Detection',
      type: 'camera',
      position: { x: 1250, y: 200 },
      status: systemStatus.ppeDetection,
      data: { yolo: 'YOLOv8' },
      description: 'Safety Equipment Detection'
    }
  ]

  const connections = [
    { from: 'sensors', to: 'vfd' },
    { from: 'vfd', to: 'plc' },
    { from: 'plc', to: 'esp32' },
    { from: 'esp32', to: 'mqtt' },
    { from: 'mqtt', to: 'influxdb' },
    { from: 'influxdb', to: 'artwin' },
    { from: 'influxdb', to: 'rul' },
    { from: 'esp32', to: 'anomaly' },
    { from: 'influxdb', to: 'ppe' }
  ]

  const getNodePosition = (nodeId) => {
    const node = nodes.find(n => n.id === nodeId)
    return node ? node.position : { x: 0, y: 0 }
  }

  return (
    <div className="relative w-full h-96 bg-cyber-gray/10 rounded-lg border border-cyber-blue/30 overflow-hidden">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#00f5ff" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Flow Connections */}
      {connections.map((connection, index) => (
        <FlowConnection
          key={`${connection.from}-${connection.to}`}
          from={getNodePosition(connection.from)}
          to={getNodePosition(connection.to)}
          active={dataFlow}
          delay={index * 0.2}
        />
      ))}

      {/* System Nodes */}
      {nodes.map((node, index) => (
        <motion.div
          key={node.id}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          style={{
            position: 'absolute',
            left: node.position.x,
            top: node.position.y,
            transform: 'translate(-50%, -50%)'
          }}
        >
          <SystemNode
            {...node}
            onClick={() => onNodeClick(node.id)}
          />
        </motion.div>
      ))}
    </div>
  )
}

export default SystemFlow
