import React from 'react'
import { motion } from 'framer-motion'
import { 
  Cpu, 
  Zap, 
  Wifi, 
  Database, 
  Eye, 
  Shield, 
  Activity,
  Camera,
  AlertTriangle,
  Gauge
} from 'lucide-react'

const SystemNode = ({ id, name, type, status, data, description, onClick }) => {
  const getNodeIcon = (type) => {
    switch (type) {
      case 'sensor': return <Gauge className="w-6 h-6" />
      case 'vfd': return <Zap className="w-6 h-6" />
      case 'plc': return <Cpu className="w-6 h-6" />
      case 'esp32': return <Wifi className="w-6 h-6" />
      case 'mqtt': return <Activity className="w-6 h-6" />
      case 'database': return <Database className="w-6 h-6" />
      case 'ar': return <Eye className="w-6 h-6" />
      case 'ai': return <Cpu className="w-6 h-6" />
      case 'alert': return <AlertTriangle className="w-6 h-6" />
      case 'camera': return <Camera className="w-6 h-6" />
      default: return <Activity className="w-6 h-6" />
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'border-cyber-green shadow-neon-green'
      case 'warning': return 'border-yellow-400 shadow-yellow-400'
      case 'alert': return 'border-red-400 shadow-red-400'
      default: return 'border-cyber-blue shadow-neon-blue'
    }
  }

  const getStatusGlow = (status) => {
    switch (status) {
      case 'active': return '#00ff41'
      case 'warning': return '#fbbf24'
      case 'alert': return '#f87171'
      default: return '#00f5ff'
    }
  }

  return (
    <motion.div
      className={`relative group cursor-pointer`}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
    >
      {/* Node Container */}
      <motion.div
        className={`
          w-20 h-20 rounded-full border-2 
          bg-cyber-gray/80 backdrop-blur-sm
          flex items-center justify-center
          transition-all duration-300
          ${getStatusColor(status)}
        `}
        animate={{
          boxShadow: [
            `0 0 20px ${getStatusGlow(status)}`,
            `0 0 30px ${getStatusGlow(status)}`,
            `0 0 20px ${getStatusGlow(status)}`
          ]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        {/* Icon */}
        <motion.div
          className="text-white"
          animate={{ rotate: type === 'esp32' ? [0, 360] : 0 }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
        >
          {getNodeIcon(type)}
        </motion.div>

        {/* Status Indicator */}
        <div 
          className={`absolute -top-1 -right-1 w-4 h-4 rounded-full ${
            status === 'active' ? 'bg-cyber-green' :
            status === 'warning' ? 'bg-yellow-400' :
            status === 'alert' ? 'bg-red-400' : 'bg-cyber-blue'
          }`}
        />
      </motion.div>

      {/* Node Label */}
      <motion.div
        className="absolute top-24 left-1/2 transform -translate-x-1/2 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <div className="text-xs font-mono text-cyber-blue whitespace-nowrap">
          {name}
        </div>
        <div className="text-xs text-gray-400 whitespace-nowrap">
          {description}
        </div>
      </motion.div>

      {/* Hover Info Panel */}
      <motion.div
        className="absolute -top-16 left-1/2 transform -translate-x-1/2 
                   bg-cyber-gray/90 backdrop-blur-sm border border-cyber-blue/50 
                   rounded-lg p-2 text-xs whitespace-nowrap opacity-0 group-hover:opacity-100
                   transition-opacity duration-300 z-10"
      >
        <div className="text-cyber-blue font-semibold">{name}</div>
        {data && (
          <div className="text-gray-300 mt-1">
            {typeof data === 'object' ? (
              Object.entries(data).map(([key, value]) => (
                <div key={key}>
                  {key}: {typeof value === 'object' ? JSON.stringify(value) : value}
                </div>
              ))
            ) : (
              <div>{data}</div>
            )}
          </div>
        )}
      </motion.div>

      {/* Data Flow Indicator */}
      {status === 'active' && (
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-cyber-blue/30"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.7, 0, 0.7]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
    </motion.div>
  )
}

export default SystemNode
